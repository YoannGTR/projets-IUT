/************************************************
 **  MINIMAL SET OF INCLUDES FOR THIS PROGRAM  **
 ************************************************/
// allows the display of errors in the standard error channel
#include <stdio.h>
// basics such as EXIT_SUCCESS and so on ...
#include <stdlib.h>
// allows to use string conversions
#include <string.h>
// allows to use boolean values
#include <stdbool.h>

/*******************************************
 **  PLACE HERE YOUR FUNCTION'S INCLUDES  ** 
 *******************************************/
// #include ...


/*******************************************************************
 **  Set this value to the number of parameters of your function  **
 *******************************************************************/
#define NBARGS 2


/************************
 **  FUNCTION HEADERS  **
 ************************/
int stringToInt(char *);
char stringToChar(char *);
float stringToFloat(char *);
void stringToGrid(char *, char[6][7]);
bool stringToBool(char *);

void displayInt(int, int);
void displayChar(int, char);
void displayFloat(int, float);
void displayString(int, char *);
void displayGrid(int, char[6][7]);
void displayBool(int, bool);

void checkArgs(int, char * []);
void displayArgs(int, char * []);
void displayErr(char *);


/********************************
 **  PLACE YOUR FUNCTION HERE  **
 ********************************/
// Your function ...
int sub(int a, int b) {
    return a - b;
}


/*********************************************************************
 **                       CORE OF THE PROGRAM                       **
 **                    -------------------------                    **
 **  PLACE HERE THE CALL TO YOUR FUNCTION AND DISPLAY THE RESPONSE  **
 *********************************************************************/
int main(int argc, char* argv[]) {
    // do not forget to check the definition of NBARGS.
    checkArgs(argc, argv);

    // duplicate this line as much as needed.
    // replace 2 by the numero of your argument and multiply it by 2. i.e.:
    // 1st arg : 2
    // 2nd arg : 4
    // 3rd arg : 6
    // and so on ...
    char* arg1 = argv[2];
    char* arg2 = argv[4];

    int res = sub(stringToInt(arg1), stringToInt(arg2));
    displayInt(1, res);

    return EXIT_SUCCESS;
}


/**************************************************
 **         DO NOT TOUCH THE CODE BELOW          **
 **      ---------------------------------       **
 **  UNLESS YOU KNOW EXACTLY WHAT YOU ARE DOING  **
 **************************************************/

/************************
 **  TYPE CONVERSIONS  **
 ************************/
int stringToInt(char * arg) {
    return atoi(arg);
}

char stringToChar(char * arg) {
    return arg[0];
}

float stringToFloat(char * arg) {
    return atof(arg);
}

void stringToGrid(char * arg, char g[6][7]) {
    for(int ii = 0 ; ii < 6 ; ii++) {
        for(int jj = 0 ; jj < 7 ; jj++) {
            g[ii][jj] = arg[(ii * 7) + jj];
        }
    }
}

bool stringToBool(char * arg) {
    return (strcmp(arg, "true") == 0);
}

/*******************************************
 **  DISPLAY OF YOUR FUNCTION'S RESPONSE  **
 *******************************************/
void displayInt(int pos, int res) {
    fprintf(stdout, "Output #%d (int): %d\n", pos, res);
}

void displayChar(int pos, char res) {
    fprintf(stdout, "Output #%d (char): %c\n", pos, res);
}

void displayFloat(int pos, float res) {
    fprintf(stdout, "Output #%d (float): %.2f\n", pos, res);
}

void displayString(int pos, char * res) {
    fprintf(stdout, "Output #%d (string): %s\n", pos, res);
}

void displayGrid(int pos, char g[6][7]) {
    fprintf(stdout, "Output #%d (grid): ", pos);
    for (int ii = 0 ; ii < 6 ; ii++) {
        for (int jj = 0 ; jj < 7 ; jj++) {
            fprintf(stdout, "%c", g[ii][jj]);
        }
    }
    fprintf(stdout, "\n");
}

void displayBool(int pos, bool res) {
    fprintf(stdout, "Output #%d (bool): %s\n", pos, res ? "true" : "false" );
}

/****************************************
 **  NUMBER OF ARGUMENTS VERIFICATION  **
 ****************************************/
void checkArgs(int argc, char * argv[]) {
    char err[512];
    if (argc % 2 == 0) {
        sprintf(err, "Incorrect number of args.\nMust be given a type followed by a value, for each param. %d args given", argc);
        displayErr(err);
        displayArgs(argc, argv);
        exit(EXIT_FAILURE);
    }
    if (argc != (2 * NBARGS + 1) ) {
        sprintf(err, "Incorrect number of args, %d args were specified while %d were given", NBARGS, ((argc-1)/2));
        displayErr(err);
        displayArgs(argc, argv);
        exit(EXIT_FAILURE);
    }
}

void displayArgs(int argc, char * argv[]) {
    fprintf(stderr, "Given args: ");
    for (int ii = 1 ; ii < argc ; ii++) {
        fprintf(stderr, "%s\t", argv[ii]);
    }
    fprintf(stderr, "\n");
}

void displayErr(char * err) {
    fprintf(stderr, "error %s\n", err);
    exit(EXIT_FAILURE);
}
