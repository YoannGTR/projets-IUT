# Unit Test Automation Helper

Hi there! Welcome to this tutorial on **UTAH**!!

*UTAH have been created by Clément Porhiel and is intended to the first years of the Computer Sciences department at the University Institute of Technology of Lannion, for the year 2022-2023.*

The purpose of this document is to learn how to use the Unit Test Automation Helper project (referred to UTAH in this document), and integrate it into the present project.

*The students of the Computer Sciences department of the UIT of Lannion (referred to students in this document) and their teachers are free to update this project as they wish under the condition of quoting the creator of this project. For more pieces of information, please refer to the creator of this project.*

To integrate UTAH in your project, please be aware of the structure of UTAH. Please note that this project only works on Linux. No support could be provided on other operating systems.

## Structure

You may see in the main folder a subfolder `src`, and four files : `.env`, `README.md` (the current document), `script.sh`, `tests.json`.

In the few next paragraphs, we will dive into these different elements:
- `src` folder is the place (by default) where you will need to place your C files. We will explain how you can integrate your functions into this folder.
- `tests.json` file is your test notebook. Usage of this file will be detailed.
- `.env` file is a configuration file where you can for instance **put your session id** or modify the paths of some files/folders.
- `README.md` file has to be read to understand how UTAH works. Please continue your reading until the end of this document.
- `script.sh` file is the core of UTAH. Normally, you shouldn't have to update this file. If you notice a problem in how does UTAH works, please get in touch with the creator of UTAH, they may ask you to update this file. You still can read it to know how it's done but you don't have to!

## C files integration

Here, we will discover the steps to integrate your functions in UTAH.
But at first, let's dive into the `src/sample.c` file! Here is how it's built:
1. **Includes.** Place your own if they aren't already used.
2. **Number of arguments.** This constant defines the number of arguments you are awaiting. *See also section #7 for its usage.*
3. **Function headers.** This section specifies all the available functions. Your own function doesn't need to be specified here.
4. **Your own function.** **For each** of your functions, **duplicate** this file and **replace** the sample function by your own function. Do not forget to set the number of argument constant! *If your function need other function, then copy and paste all of the needed function at this specific place.*
5. **Main function.** To call your function, please follow the following steps:
    1. Use argv[] as described to call your parameters.
    2. Convert your parameters with the corresponding given function. i.e.: `stringToFloat()`.
    3. Use it as parameters of your function / procedure.
    4. Display the result by using the corresponding given function. i.e.: `displayInt()`. *Respecting the order with the `pos` parameter isn't mandatory but it might help you organize yourself.*
6. **Conversions and Responses.** The types `int`, `char`, `float`, `grid`, `bool` are supported. Please note that the `arg` parameter is the string you want to convert *(The format of your test notebook forces the parameters to be given as strings)*. 
7. Args and errors. The first function counts the number of arguments and checks if that one is correct corresponding to the `NBARGS` constant defined in the section #2. **If you want to throw errors**, please use the `displayErr()` function

## Fill your test notebook
Now that we have seen how you can integrate your function into UTAH, let's dive into your test notebook. You may see the file `tests.json` and use it as an example. Here is an instance of a test case:
```json
{
    "test_num": 1,
    "test_label": "Test sum nb pos & neg",
    "file_name": "sum.c",
    "goals": [
        {
            "type": "int",
            "val": "-3"
        }
    ],
    "args": [
        {
            "type": "int",
            "val": "4"
        },
        {
            "type": "int",
            "val": "-7"
        }
    ]
}
```
For each test case, you must give:
1. **`test_num`**: **This is the number of your test.** *You may for instance make it start with `1` and increment it at each test case.*
2. **`test_label`**: **This is the description of your test.** *The more detailed, the better. Try to be really specific. this description must justify the usefulness of the test.*
3. **`file_name`**: *normally, if you understood well the previous section, you should know that every function to test is located in a different file.* **This field is used here to indicate in which file is located your function.** *The `main` function will then be called in this specific file. that's why you should call your own function from the `main`.*
4. **`goals`**: **This is the result you are awaiting from your function.** This mustn't be a description of the result but the result itself. *In the example, we are awaiting from a sum function the result `-3` which is an `int` when it was given those arguments. Some functions may need two or more results. that's why `goals` is an array.*
5. **`args`**: **These are the arguments you are going to give to your function.** It means you mustn't describe what is going to be in there but put it directly. Then you must create examples from your bare hands *(or bare fingers actually)*. **The arguments have a type and a value. these still must stand in strings.** *You may see instances of those arguments in the `tests.json` file.*

### Grid management in JSON
In the JavaScript Object Notation (JSON), multiline parameters aren't supported. You must then concatenate each row of your grid into the same line. Here is an example:
```json
{
    "type": "grid",
    "val": "..............x......oxo....ooxo...oxox..."
}
```

### Errors management in the test notebook
If you await your function to throw an error, please specify the type `error` as your goal, with as it's value the error message you are awaiting. Here is an example:
```json
{
    "type": "error",
    "val": "Incorrect number of args, 1 args were specified while 2 were given"
}
```

## Setup the `.env` config file
In this file, you may find some settings. Normaly, you shouldn't set most of these but you still can if you want to do so. Please be aware that if you change these, there might be some consequences.
Still, you have to fill the `STUD_ID` by your session.

## Execute the script
So as not to beat around the bush, here is the command you have to execute on your terminal. You still must be located in the folder.
```
./script.sh
```
This command will compile in the `bin` folder (by default, it will be created at the same time) your C code located by default in `src`. No need to delete the previous binary files, those will be automatically replaced.

At each execution of the script, a markdown file will be generated in the `result` folder (by default). The filename contains your `session id`, the `date` and the `time` of execution, so as you can keep an historic of test execution.

## Interprete the result file

In the following paragraphs, we will observ the generated file located in `result` folder (by default).

In the first lines of the file, you may find the time and the author of the test execution (your session id).

Each test case is formatted this way:
- The status of the test, by an emote
- The number of the test.
- The test description
- The name of the C file concerned by the test
- A recap of the arguments
- A recap of your goal(s)
- The result obtained by your fonction, given the said arguments
- The written format of the status of your test.

When the test is ✅ PASSED, everything is allright! 

When the test is ❌ FAILED, there are no errors thrown by the program but the result of the function differs from the awaited value 

When the test is 💥 ERROR, it means an error is thrown by the program, either you have decided by your own to throw this error or you haven't planned to. *You may also want to test if the program throws an error. to do so, please use the displayErr() function.*

## That's all folks!
