#!/usr/bin/bash

#############################
##  ENVIRONMENT VARIABLES  ##
#############################
echo "DOING - collecting information pieces from environment file ..."
source .env
echo "DONE - environment variables collected."

########################
##  MANAGE ALL TESTS  ##
########################

now=$(date +'%y%m%d-%H%M%S')

if [[ ! -d $RESULT_DIR_PATH ]]; then
    mkdir $RESULT_DIR_PATH
fi
if [[ ! -d $BINFILES_DIR_PATH ]]; then
    mkdir $BINFILES_DIR_PATH
fi

result_file="${RESULT_DIR_PATH}/${RESULT_FILE_NAME_LEADING}-${STUD_ID}-${now}.${RESULT_FILE_EXT}"

nb_passed=0

# Initiate the creation of the result file
echo "# Automated tests

**Time**: *$now*

**Author**: *$STUD_ID*

---

" > $result_file

# Get the number of tests in the test file
nbTests=$(grep -c 'test_num' < "${TEST_PROTOCOL_FILE_PATH}")

# Test iterator
testIndex=1
# Compiled files storage
declare -A compil

while ((testIndex <= nbTests)); do

    ################################
    ##  READ THE TEST DESCRIPTOR  ##
    ################################

    # Leading line of the test descriptor
    test_desc_begin=$(grep -no 'test_num' < $TEST_PROTOCOL_FILE_PATH | cut -d: -f 1 | head -n $testIndex | tail -n -1)

    if [[ $testIndex -eq $nbTests ]]; then
        # Exception case #1: end of the file. The end of the test descriptor is located at the line of the last closing brace '}'.

        # Trailing line of the test descriptor
        test_desc_end=$(( $(grep -no '}' < tests.json | tail -1 | cut -d: -f 1) -1 ))
    else
        # Nominal case: The end of the test descriptor is located at the line of the last closing brace before the next test descriptor.

        # Trailing line of the test descriptor
        test_desc_end=$(( $(grep -no 'test_num' < $TEST_PROTOCOL_FILE_PATH | cut -d: -f 1 | head -n $((testIndex+1)) | tail -n -1) -3 ))
    fi

    # Length of the test descriptor
    test_desc_len=$((test_desc_end - test_desc_begin + 1))

    # Test descriptor
    test_desc=$(head -n "$test_desc_end" < $TEST_PROTOCOL_FILE_PATH | tail -n "-$test_desc_len")
    
    # Test num
    test_num=$(echo ${test_desc} | sed -r 's/.*"test_num": ([^,]*),.*/\1/')

    # Test label
    test_label=$(echo ${test_desc} | sed -r 's/.*"test_label": "([^"]*)".*/\1/')


    #####################
    ##  APPLY FILTERS  ##
    #####################

    # Name of the file to execute, given from the test descriptor
    test_desc_file_name=$(echo "$test_desc" | grep 'file_name' | sed -r 's/\ *"file_name": "(.*)",\ ?/\1/')
    # Check if the file name is filtered in ENV variables
    if echo "${FILTER[@]}" | grep -Fqz -- "$test_desc_file_name"; then
        # Avoid to run into an infinity loop
        testIndex=$((testIndex+1))
        # The file has been filtered, do not execute anything after this line for this test
        continue
    fi

    ##########################################################
    ##  READ THE ARG-S AND THE GOAL-S FROM FILE DESCRIPTOR  ##
    ##########################################################
    IFS=' ' read -r -a test_args <<< $(echo ${test_desc} | sed -r 's/.*"args": \[ ([^]]*) \].*/\1/' | sed -r 's/\{ "type": "([^"]*)", "val": "([^"]*)" \},?/\1 \2/g')
    IFS=' ' read -r -a test_goals <<< $(echo ${test_desc} | sed -r 's/.*"goals": \[ ([^]]*) \].*/\1/' | sed -r 's/\{ "type": "([^"]*)", "val": "([^"]*)" \},?/\1 \2/g')

    ##################################################
    ##  COMPILE THE C FILE IF NOT ALREADY COMPILED  ##
    ##################################################

    # Name of the executable file created after compilation of the C file
    exename=${test_desc_file_name::-2}
    if [[ -z "${compil[$exename]}" ]]; then
        # The file hasn't been compiled yet
        echo "Compiling ${CFILES_DIR_PATH}/${test_desc_file_name} ..."
        gcc -Wall "${CFILES_DIR_PATH}/${test_desc_file_name}" -o "${BINFILES_DIR_PATH}/${exename}" 2> tmpErr >&2
        # Check if the file has been compiled of if an error happened
        if [[ -z "${compil[$exename]}" ]]; then
            # declare the file as compiled
            compil[$exename]="done"
            echo "Compilation of ${CFILES_DIR_PATH}/${test_desc_file_name} done"
        else
            echo "Compilation error occured in ${CFILES_DIR_PATH}/${test_desc_file_name}"
            break
        fi
    fi

    ################################################
    ##  EXECUTE THE PROGRAM WITH GIVEN ARGUMENTS  ##
    ################################################

    if [[ -z $(cat tmpErr) ]]; then
        "${BINFILES_DIR_PATH}/${exename}" ${test_args[*]} > tmpOut 2> tmpErr
    fi
    
    #################################
    ##  INTERPRETE PROGRAM OUTPUT  ##
    #################################
    
    if [[ -z $(cat tmpErr) ]]; then
        # No error was found
        IFS=' ' read -r -a res <<< $(grep '^Output #' < tmpOut | sed -r 's/.*\((.*)\): (.*)/\1 \2/' | tr '\n' ' ')

        if [[ ${test_goals[0]} == "error" ]]; then
            status="TEST FAILED"
            status_moji=❌
        else
            if [[ "${test_goals[@]% }" == "${res[@]% }" ]]; then
                # The result does not differ from the goal then the test is PASSED
                status="TEST PASSED"
                status_moji=✅
                nb_passed=$((nb_passed+1))
            else
                # The result differs from the goal then the test is FAILED
                status="TEST FAILED"
                status_moji=❌
            fi
        fi
    else
        goal="${test_goals[*]}"
        error="$(cat tmpErr)"
        if [[ ${test_goals[0]} == "error" ]]; then
            if [[ $goal == $error ]]; then
                status="TEST PASSED"
                status_moji=✅
                nb_passed=$((nb_passed+1))
            else
                status="ERROR"
                status_moji=💥
                # Read the error came from the stderr output channel
                err_msg=$(cat tmpErr)
            fi
        else
            # An error was found, either in the compilation or the execution
            status="ERROR"
            status_moji=💥
            # Read the error came from the stderr output channel
            err_msg=$(cat tmpErr)
        fi
    fi
    nb_args=$((${#test_args[@]}/2))
    nb_goals=$((${#test_goals[@]}/2))
    nb_res=$((${#res[@]}/2))


    echo "## ${status_moji} **Test #${test_num}**: *\`${test_label}\`*
> **Filename**: *\`${test_desc_file_name}\`*
> 
> **Args**:" >> $result_file
    for ((i = 0 ; i < $nb_args ; i++)); do
        echo "> * **\`${test_args[$((2*i+1))]}\`** (*${test_args[$((2*i))]}*)" >> $result_file
    done
    echo "> 
> **Goals**:" >> $result_file

    if [[ ${test_goals[0]} == "error" ]]; then
        echo "> \`\`\`" >> $result_file
        echo ${test_goals[@]} | sed -r 's/^(.*)/> \1/g' >> $result_file
        echo "> \`\`\`" >> $result_file
    else
        for ((i = 0 ; i < $nb_goals ; i++)); do
            echo "> * **\`${test_goals[$((2*i+1))]}\`** (*${test_goals[$((2*i))]}*)" >> $result_file
        done
    fi
    echo "> 
> **Results**:" >> $result_file
    if [[ -z $(cat tmpErr) ]]; then
        for ((i = 0 ; i < $nb_res ; i++)); do
            echo "> * **\`${res[$((2*i+1))]}\`** (*${res[$((2*i))]}*)" >> $result_file
        done
    else
        echo "> \`\`\`" >> $result_file
        cat tmpErr | sed -r 's/^(.*)/> \1/g' >> $result_file
        echo "> \`\`\`" >> $result_file
    fi
    echo "> 
> ---
> 
> **${status}**
" >> $result_file

    testIndex=$((testIndex+1)) # iterate through the tests
done

echo "---

***\`${nb_passed}\`** test **PASSED** out of **\`${nbTests}\`***" >> $result_file

rm tmp*