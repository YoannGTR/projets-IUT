package appli;

import back.*;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage; 

public class FenAffichageClient extends Stage{
	public FenAffichageClient()
	{
		this.setTitle("AffichageClient"); 
		Scene laScene = new Scene(creerContenu());
		this.setScene(laScene);
		this.sizeToScene();
		this.setResizable(false);
	}
	private VBox racine = new VBox();
	Label clientLabel = new Label("Client");
	private Label nom = new Label("Nom :");
	private TextField nomField = new TextField();
	private Label prenom = new Label("Prénom :");
	private TextField prenomField = new TextField();
	private Label telephone = new Label("Téléphone :");
	private TextField telephoneField = new TextField();
	private Label mail = new Label("Mail :");
	private TextField mailField = new TextField();
	private Label adresse = new Label("Adresse :");
	private TextField adresseField = new TextField();
	private TextField adresseField2 = new TextField();
	private Label ville = new Label("Ville :");
	private TextField villeField = new TextField();
	private TextField villeField2 = new TextField();
	private Label codePostal = new Label("Code postal");
	private TextField codePostalField = new TextField();
	private TextField codePostalField2 = new TextField();
	private HBox noms = new HBox();
	private HBox prenoms = new HBox();
	private HBox telephones = new HBox();
	private HBox mails = new HBox();
	private HBox adresses = new HBox();
	private HBox villes = new HBox();
	private HBox codePotals = new HBox();
	public Parent creerContenu()
	{
		// donnees.setText("test");
		noms.getChildren().addAll(nom,nomField);
		prenoms.getChildren().addAll(prenom,prenomField);
		telephones.getChildren().addAll(telephone,telephoneField);
		mails.getChildren().addAll(mail,mailField);
		adresses.getChildren().addAll(adresse,adresseField,adresseField2);
		villes.getChildren().addAll(ville,villeField,villeField2);
		codePotals.getChildren().addAll(codePostal,codePostalField,codePostalField2);
		racine.getChildren().addAll(clientLabel,noms,prenoms,telephones,mails,adresses,villes,codePotals);
		return racine;
	}
	public void creer(Client cli)
	{
		clientLabel.setStyle("-fx-font-weight: bold;"
                + "-fx-border-color: #FFFFFF;"
                + "-fx-border-width: 0 0 1 0;"
                + "-fx-underline: true;"
                + "-fx-font: 20 arial;");
//		donnees0.setText(""+cli.getNomClient());
//		donnees1.setText(cli.getPrenomClient());
//		donnees2.setText(cli.getAdresse());
//		donnees3.setText(cli.getNumeroTelClient());
//		donnees4.setText(cli.getNumClient());
//		donnees5.setText(cli.getVille());
		// donnees6.setText(res.getChambre_res());
	}
	public void init(Client cli)
	{
		creer(cli);
		   
	}
}