package appli;

import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.paint.Color;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import back.AccesDonees;
import back.Chambre;
import back.Client;
import back.Reservation;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class FenAffichageReservation extends Stage{
	
	public FenAffichageReservation()
	{
		this.setTitle("Affichage R�servation");
		Scene laScene = new Scene(creerContenu(AccesDonees.getLesRes().get(1))); 
		this.setScene(laScene);
		this.sizeToScene();
		this.setResizable(false);
	}
	
	private BorderPane mainLayout = new BorderPane();
	private HBox center = new HBox();
	private HBox header = new HBox();
	
	private GridPane formGridPane = new GridPane();
	private TableView<Chambre> tableView = new TableView<>();
	
	private Label title = new Label();
	private TextField fieldNumRes = new TextField();
	private VBox boxNumRes = new VBox();
	private HBox hBoxBoutons = new HBox();
	private Button supprimer = new Button("Supprimer");
	private Button modifier = new Button("Modifier  ");
	private Button annuler = new Button(" Annuler   ");
	private Button confirmer = new Button("Confirmer");
	private HBox spacer = new HBox();
	private VBox warningBox = new VBox();
	private Label warning1 = new Label();
	
	private HBox footer = new HBox();
	private Button retour = new Button("Retour");
	
	public BorderPane creerContenu(Reservation res)
	{
		
        
        title.setText("Num�ro de r�servation");
        title.setTextFill(Color.WHITE);
        title.setStyle("-fx-font-size: 20; -fx-text-fill: white; -fx-padding: 10;");
        
        fieldNumRes.setText(res.getNum_res());
        fieldNumRes.setEditable(false);
        fieldNumRes.setMaxWidth(90);
        fieldNumRes.setStyle("-fx-background-color: #D9D9D9; -fx-text-fill: black; -fx-font-size: 15;");
        fieldNumRes.setFocusTraversable(false);
        boxNumRes.getChildren().add(fieldNumRes);
        boxNumRes.setMaxHeight(50);
        boxNumRes.setStyle("-fx-background-color: #D9D9D9; -fx-padding: 0px 20px; -fx-background-radius:5px;");
        boxNumRes.setAlignment(Pos.CENTER);
        
        
        
		warningBox.getChildren().add(warning1);
		warningBox.setAlignment(Pos.CENTER_LEFT);
		warningBox.setStyle("-fx-background-radius:5px;");
        
        supprimer.setPadding(new Insets(10));
        supprimer.setOnAction(e->{
        	Stage test = new FenAffichageReservation();
        	test.show();
        	this.close();
        });
        
        modifier.setPadding(new Insets(10));
        modifier.setOnAction(e->creerModif(res));
        
        annuler.setPadding(new Insets(10));
        annuler.setOnAction(e->resetModif(res));
        
        confirmer.setPadding(new Insets(10));
        confirmer.setOnAction(e->applyModif(res));
        
        hBoxBoutons.setSpacing(10);
        hBoxBoutons.setPadding(new Insets(10));
        hBoxBoutons.getChildren().addAll(supprimer, modifier);
        HBox.setHgrow(spacer, Priority.ALWAYS);
        
        header.setPadding(new Insets(15,0,15,5));
        
		header.getChildren().addAll(title, boxNumRes, spacer, hBoxBoutons);
        header.setAlignment(Pos.CENTER);
        header.setStyle("-fx-background-color: #4070EC;");
        header.setSpacing(10);
        
        retour.setPadding(new Insets(10));
        footer.setPadding(new Insets(10));
        retour.setAlignment(Pos.CENTER);
        footer.getChildren().addAll(retour);
        
        formGridPane = createFormGridPane(res);
        tableView = createTableView(res);
        
        center.getChildren().addAll(formGridPane, tableView);
        center.setSpacing(40);
        center.setPadding(new Insets(20,40,0,40));
		
		mainLayout.setTop(header);
		mainLayout.setCenter(center);
		mainLayout.setBottom(footer);
		return mainLayout;
	}
	
	public void creerModif(Reservation res)
	{
		this.setTitle("Modification");
		hBoxBoutons.getChildren().clear();
		hBoxBoutons.getChildren().addAll(annuler, confirmer);
		fieldNumRes.setStyle("-fx-text-fill: black; -fx-font-size: 15;");
		header.getChildren().clear();
		HBox.setHgrow(warningBox, Priority.ALWAYS);
		header.getChildren().addAll(title, boxNumRes, warningBox, hBoxBoutons);
		warning1.setText("");
		warning2.setText("");
		warning3.setText("");
		warning4.setText("");
		warning1.setTextFill(Color.RED);
		warning1.setStyle("-fx-font-size:12;"
						+ "-fx-padding: 10px;");

		
		dateEnd.setStyle("");
		dateStart.setStyle("");
		
		fieldNumRes.setEditable(true);
		dateStart.setEditable(true);
		dateEnd.setEditable(true);
		
		formGridPane.getChildren().clear();
		formGridPane.add(clientLabel, 0, 0);
        formGridPane.add(numberLabel, 0, 1);
        formGridPane.add(numberTextField, 1, 1);
        formGridPane.add(warning2, 0, 2, 2,1);
        formGridPane.add(dateLabel, 0, 3);
        formGridPane.add(startDateLabel, 0, 4);
        formGridPane.add(startDatePicker, 1, 4);
        formGridPane.add(warning3, 0, 5, 2,1);
        formGridPane.add(endDateLabel, 0, 6);
        formGridPane.add(endDatePicker, 1, 6);
        formGridPane.add(warning4, 0, 7, 2,1);
	}
	
	public void resetModif(Reservation res)
	{
		this.setTitle("Affichage R�servation");
		hBoxBoutons.getChildren().clear();
		hBoxBoutons.getChildren().addAll(supprimer, modifier);
		fieldNumRes.setStyle("-fx-background-color: #D9D9D9; -fx-text-fill: black; -fx-font-size: 15;");
		header.getChildren().clear();
		HBox.setHgrow(spacer, Priority.ALWAYS);
		header.getChildren().addAll(title, boxNumRes, spacer, hBoxBoutons);
		warning1.setStyle("");
		
		name.setStyle("-fx-background-color: #D9D9D9; -fx-text-fill: black; -fx-font-size: 15; -fx-padding: 2 10;");
		number.setStyle("-fx-background-color: #D9D9D9; -fx-text-fill: black; -fx-font-size: 15; -fx-padding: 2 10;");
		dateStart.setStyle("-fx-background-color: #D9D9D9; -fx-text-fill: black; -fx-font-size: 15; -fx-padding: 2 10;");
		dateEnd.setStyle("-fx-background-color: #D9D9D9; -fx-text-fill: black; -fx-font-size: 15; -fx-padding: 2 10;");
		
		fieldNumRes.setEditable(false);
		dateStart.setEditable(false);
		dateEnd.setEditable(false);
		
		formGridPane.getChildren().clear();
		formGridPane.add(clientLabel, 0, 0);
        formGridPane.add(nameLabel, 0, 1);
        formGridPane.add(nameTextField, 1, 1);
        formGridPane.add(numberLabel, 0, 2);
        formGridPane.add(numberTextField, 1, 2);
        formGridPane.add(dateLabel, 0, 3);
        formGridPane.add(startDateLabel, 0, 4);
        formGridPane.add(startDatePicker, 1, 4);
        formGridPane.add(endDateLabel, 0, 5);
        formGridPane.add(endDatePicker, 1, 5);
	}
	public void applyModif(Reservation res)
	{
		String texte = fieldNumRes.getText().replaceAll("\\s", "");
		if(verifyNumR(texte))
		{
			
		}
	}
	public boolean verifyNumR(String texte)
	{
		if(texte.isEmpty())
		{
			warning1.setStyle("-fx-font-size:12;"
					+ "-fx-padding: 10px;"
					+ "-fx-background-color:lightgray;"
					+ "-fx-background-radius:5px;");
			warning1.setText("Champs obligatoire");
		}
		else 
		{
			try 
			{
				Integer.parseInt(texte);
				//verifier si dans base de donn�es
				
				if(texte.length()!=8)
				{
					warning1.setStyle("-fx-font-size:12;"
							+ "-fx-padding: 10px;"
							+ "-fx-background-color:lightgray;"
							+ "-fx-background-radius:5px;");
					warning1.setText("Le num�ro de r�servation\nest compos� de 8 chiffres");
				}
				else
				{
					if(!resExist(texte))
					{
						return true;
					}
					else
					{
						warning1.setStyle("-fx-font-size:12;"
								+ "-fx-padding: 10px;"
								+ "-fx-background-color:lightgray;"
								+ "-fx-background-radius:5px;");
						warning1.setText("Ce num�ro de r�servation \nn'existe pas");
					}
				}
			}
			catch (Exception e) {
				warning1.setStyle("-fx-font-size:12;"
						+ "-fx-padding: 10px;"
						+ "-fx-background-color:lightgray;"
						+ "-fx-background-radius:5px;");
				warning1.setText("Le num�ro de r�servation\n ne doit �tre compos�\n que de chiffres");
			}
		}
		return false;
	}
	public boolean resExist(String numRes)
	{
		Reservation res = AccesDonees.getReservation(numRes); 
		if(res== null)
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	
	private Label clientLabel = new Label("Client");
	private Label nameLabel = new Label("Pr�nom et nom du client :");
	private TextField name = new TextField("Camille Onette");
	private VBox nameTextField = new VBox();
	private Label numberLabel = new Label("Num�ro du client :");
    private TextField number = new TextField("55881451441");
    private VBox numberTextField = new VBox();
    private Label dateLabel = new Label("Dates");
    private Label startDateLabel = new Label("Date de d�but de s�jour :  ");
    private TextField dateStart = new TextField("12-06-2023");
    private VBox startDatePicker = new VBox();
    private Label endDateLabel = new Label("Date de fin de s�jour :");
    private TextField dateEnd = new TextField("18-06-2023");
    private VBox endDatePicker = new VBox();
    
    
	private Label warning2 = new Label();
	private Label warning3 = new Label();
	private Label warning4 = new Label();
	
	
    private GridPane createFormGridPane(Reservation res) {
        
    	formGridPane.setPadding(new Insets(10));
    	formGridPane.setHgap(10);
    	formGridPane.setVgap(10);
        
        clientLabel.setStyle("-fx-font-weight: bold;"
                + "-fx-border-color: #FFFFFF;"
                + "-fx-border-width: 0 0 1 0;"
                + "-fx-underline: true;"
                + "-fx-font: 20 arial;");
        clientLabel.setTextFill(Color.BLACK);
        
        Client client = AccesDonees.getClient(res.getNumClientRes());
        
        name.setEditable(false);
        name.setText(client.getPrenomClient()+" "+client.getNomClient());
        name.setStyle("-fx-background-color: #D9D9D9; -fx-text-fill: black; -fx-font-size: 15; -fx-padding: 2 10;");
        nameLabel.setTextFill(Color.BLACK);
        
        nameTextField.setMaxWidth(160);
        nameTextField.getChildren().add(name);
        nameTextField.setStyle("-fx-background-color: #D9D9D9;");
        nameTextField.setPadding(new Insets(10));

        
        number.setEditable(false);
        number.setText(res.getNumClientRes());
        number.setStyle("-fx-background-color: #D9D9D9; -fx-text-fill: black; -fx-font-size: 15; -fx-padding: 2 10;");
        numberLabel.setTextFill(Color.BLACK);
        
        numberTextField.setMaxWidth(160);
        numberTextField.getChildren().add(number);
        numberTextField.setStyle("-fx-background-color: #D9D9D9;");
        numberTextField.setPadding(new Insets(10));

        
        dateLabel.setStyle("-fx-font-weight: bold;"
                + "-fx-border-color: #FFFFFF;"
                + "-fx-border-width: 0 0 1 0;"
                + "-fx-underline: true;"
                + "-fx-font: 20 arial;");
        dateLabel.setTextFill(Color.BLACK);

        
        startDateLabel.setTextFill(Color.BLACK);
        
        dateStart.setEditable(false);
        dateStart.setText(res.getDate_deb_sejour_toString());
        dateStart.setStyle("-fx-background-color: #D9D9D9; -fx-text-fill: black; -fx-font-size: 15; -fx-padding: 2 10;");
        
        startDatePicker.setMaxWidth(160);
        startDatePicker.getChildren().add(dateStart);
        startDatePicker.setStyle("-fx-background-color: #D9D9D9;");
        startDatePicker.setPadding(new Insets(10));

       
        dateEnd.setEditable(false);
        dateEnd.setText(res.getDate_fin_sejour_toString());
        dateEnd.setStyle("-fx-background-color: #D9D9D9; -fx-text-fill: black; -fx-font-size: 15; -fx-padding: 2 10;");
        endDateLabel.setTextFill(Color.BLACK);
        
        endDatePicker.setMaxWidth(160);
        endDatePicker.getChildren().add(dateEnd);
        endDatePicker.setStyle("-fx-background-color: #D9D9D9;");
        endDatePicker.setPadding(new Insets(10));

        
		warning2.setTextFill(Color.RED);
		warning2.setStyle("-fx-font-size:12;"
						+ "-fx-padding: -5px 0px;");
		warning3.setTextFill(Color.RED);
		warning3.setStyle("-fx-font-size:12;"
						+ "-fx-padding: -5px 0px;");
		warning4.setTextFill(Color.RED);
		warning4.setStyle("-fx-font-size:12;"
						+ "-fx-padding: -5px 0px;");
        
        
		formGridPane.add(clientLabel, 0, 0);
        formGridPane.add(nameLabel, 0, 1);
        formGridPane.add(nameTextField, 1, 1);
        formGridPane.add(numberLabel, 0, 2);
        formGridPane.add(numberTextField, 1, 2);
        formGridPane.add(dateLabel, 0, 3);
        formGridPane.add(startDateLabel, 0, 4);
        formGridPane.add(startDatePicker, 1, 4);
        formGridPane.add(endDateLabel, 0, 5);
        formGridPane.add(endDatePicker, 1, 5);

        return formGridPane;
    }
    
    private TableColumn<Chambre, String> categorieCol = new TableColumn<>();
	private TableColumn<Chambre, Integer> numeroCol = new TableColumn<>();
	private TableColumn<Chambre, Integer> personnesCol = new TableColumn<>();

	private TableView<Chambre> createTableView(Reservation res) {
		
        categorieCol.setText("Cat�gorie(s) \nchambre(s)");
        numeroCol.setText("Num�ro(s) \nchambre(s)");
        personnesCol.setText("Nombre de \npersonnes");
        categorieCol.setStyle("-fx-alignment:CENTER;");
        numeroCol.setStyle("-fx-alignment:CENTER;");
        personnesCol.setStyle("-fx-alignment:CENTER;");
        
        categorieCol.setCellValueFactory(new PropertyValueFactory<>("categorie"));
        numeroCol.setCellValueFactory(new PropertyValueFactory<>("numero"));
        personnesCol.setCellValueFactory(new PropertyValueFactory<>("nbPersonnes"));

        // Définir les largeurs des colonnes
        categorieCol.setPrefWidth(100);
        numeroCol.setPrefWidth(100);
        personnesCol.setPrefWidth(100);
        
        // Classe de cellule personnalisée pour la couleur de fond
//        class CustomTableCell<T> extends TableCell<Chambre, T> {
//            @Override
//            public void updateItem(T item, boolean empty) {
//                super.updateItem(item, empty);
//
//                if (empty || item == null) {
//                    int index = getIndex();
//                    if (index % 2 == 0) {
//                        setBackground(new Background(new BackgroundFill(Color.web("#4070EC", 0.4), null, null)));
//                    } else {
//                        setBackground(new Background(new BackgroundFill(Color.web("#4070EC", 0.6), null, null)));
//                    }
//                    setText(null);
//                } else {
//                    int index = getIndex();
//                    if (index % 2 == 0) {
//                        setBackground(new Background(new BackgroundFill(Color.web("#4070EC", 0.4), null, null)));
//                    } else {
//                        setBackground(new Background(new BackgroundFill(Color.web("#4070EC", 0.6), null, null)));
//                    }
//                    setText(item.toString());
//                }
//            }
//        }

        // Appliquer la classe de cellule personnalisï¿½e ï¿½ chaque colonne
        categorieCol.setCellFactory(col -> new TableCell<Chambre, String>(){
        	public void updateItem(String item, boolean empty) {
	            super.updateItem(item, empty);
	
	            if (empty || item == null) {
	                  int index = getIndex();
	                  if (index % 2 == 0) {
	                      setBackground(new Background(new BackgroundFill(Color.web("#4070EC", 0.4), null, null)));
	                  } else {
	                      setBackground(new Background(new BackgroundFill(Color.web("#4070EC", 0.6), null, null)));
	                  }
	                  setText(null);
	             } 
	             else {
	                  int index = getIndex();
	                  if (index % 2 == 0) {
	                      setBackground(new Background(new BackgroundFill(Color.web("#4070EC", 0.4), null, null)));
	                  } else {
	                      setBackground(new Background(new BackgroundFill(Color.web("#4070EC", 0.6), null, null)));
	                  }
	                  setText(item.toString());
	              }
	          }
        });
        numeroCol.setCellFactory(col -> new TableCell<Chambre, Integer>(){
        	public void updateItem(Integer item, boolean empty) {
	            super.updateItem(item, empty);
	
	            if (empty || item == null) {
	                  int index = getIndex();
	                  if (index % 2 == 0) {
	                      setBackground(new Background(new BackgroundFill(Color.web("#4070EC", 0.4), null, null)));
	                  } else {
	                      setBackground(new Background(new BackgroundFill(Color.web("#4070EC", 0.6), null, null)));
	                  }
	                  setText(null);
	             } 
	             else {
	                  int index = getIndex();
	                  if (index % 2 == 0) {
	                      setBackground(new Background(new BackgroundFill(Color.web("#4070EC", 0.4), null, null)));
	                  } else {
	                      setBackground(new Background(new BackgroundFill(Color.web("#4070EC", 0.6), null, null)));
	                  }
	                  setText(item.toString());
	              }
	          }
        });
        personnesCol.setCellFactory(col -> new TableCell<Chambre, Integer>(){
        	public void updateItem(Integer item, boolean empty) {
	            super.updateItem(item, empty);
	
	            if (empty || item == null) {
	                  int index = getIndex();
	                  if (index % 2 == 0) {
	                      setBackground(new Background(new BackgroundFill(Color.web("#4070EC", 0.4), null, null)));
	                  } else {
	                      setBackground(new Background(new BackgroundFill(Color.web("#4070EC", 0.6), null, null)));
	                  }
	                  setText(null);
	             } 
	             else {
	                  int index = getIndex();
	                  if (index % 2 == 0) {
	                      setBackground(new Background(new BackgroundFill(Color.web("#4070EC", 0.4), null, null)));
	                  } else {
	                      setBackground(new Background(new BackgroundFill(Color.web("#4070EC", 0.6), null, null)));
	                  }
	                  setText(item.toString());
	              }
	          }
        });

        tableView.getColumns().addAll(categorieCol, numeroCol, personnesCol);
        
        tableView.getItems().addAll(res.getChambre_res());
        

        return tableView;
	}
	
	public void init(Reservation res)
	{
		creerContenu(res);
		   
	}

}


