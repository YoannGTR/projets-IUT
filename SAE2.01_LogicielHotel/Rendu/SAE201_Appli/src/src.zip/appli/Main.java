package appli;

import back.*;
import javafx.application.Application;
import javafx.stage.Modality;
import javafx.stage.Stage; 
 
public class Main extends Application
{
//	static private FenAffichageRes fAffRes = new FenAffichageRes();
//	static private FenAffichageC fAffCli = new FenAffichageC();
	
	public void start(Stage primaryStage){
		AccesDonees.connexion(); 
		primaryStage = new FenAffichageReservation();
//		primaryStage.show();
//		primaryStage = new FenRecapeRes();
//		primaryStage.show();
//		primaryStage = new FenRecherche();
		primaryStage.show();
//		fAffRes.initModality(Modality.APPLICATION_MODAL);
//		fAffCli.initModality(Modality.APPLICATION_MODAL);
	}
	public static void main(String[] args) {
		Application.launch(); 
	} 
	
	static public void ouvrirAffRes(String numRes) 
	{
//		fonction getRes a partir du num�ro de res
		Reservation res = AccesDonees.getReservation(numRes); 
		
//		fAffRes.init(res);
//		fAffRes.show(); 
		
		
	}
	static public void ouvrirAffClient(String donnee)
	{
//		fonction getRes a partir du num�ro de res
		boolean isNum;
		try {
			Integer.parseInt(donnee);
			isNum=true;
		} catch (Exception e) {
			isNum =false;
		}
		Client client;
		if(isNum)
		{
			client = AccesDonees.getClientViaTel(donnee); 
		}
		else
		{
			client = AccesDonees.getClientViaNom(donnee); 
		}
		
		
//		fAffCli.init(client);
//		fAffCli.show();
		
		
	}
	
}