package back;


public class Chambre  
{
        private String categorie;
        private int numero;
        private int nbPersonnes;

        public Chambre(String categorie, int numero, int nbPersonnes) {
            this.categorie = categorie;
            this.numero = numero;
            this.nbPersonnes = nbPersonnes;
        }
        public String getCategorie() {
            return categorie;
        }

        public void setCategorie(String categorie) {
            this.categorie = categorie;
        }


        public int getNumero() {
            return numero;
        }

        public void setNumero(int numero) {
            this.numero = numero;
        }


        public int getNbPersonnes() {
            return nbPersonnes;
        }

        public void setNbPersonnes(int nbPersonnes) {
            this.nbPersonnes = nbPersonnes;
        }

    }